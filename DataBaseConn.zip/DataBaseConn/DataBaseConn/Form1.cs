﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql; // Подключаем драйвер для PostgreSQL

namespace DatabaseConnectionApp
{
    public partial class MainForm : Form
    {
        private NpgsqlConnection connection; // Объект соединения с БД

        public MainForm()
        {
            InitializeComponent();
            InitializeUI(); // Настройка интерфейса
        }

        private void InitializeUI()
        {
            // Скрываем текстовые поля при запуске
            txtServer.Visible = false;
            txtDatabase.Visible = false;
            txtUser.Visible = false;
            txtPassword.Visible = false;
            txtPort.Visible = false;
            lblServer.Visible = false;
            lblDatabase.Visible = false;
            lblUser.Visible = false;
            lblPassword.Visible = false;
            lblPort.Visible = false;

            btnOpen.Enabled = false;
            btnClose.Enabled = false;
            btnExecute.Enabled = false;

            lblStatus.Text = "Соединение не установлено";
        }

        private void btnInitialize_Click(object sender, EventArgs e)
        {
            // Делаем текстовые поля видимыми
            txtServer.Visible = true;
            txtDatabase.Visible = true;
            txtUser.Visible = true;
            txtPassword.Visible = true;
            txtPort.Visible = true;

            lblServer.Visible = true;
            lblDatabase.Visible = true;
            lblUser.Visible = true;
            lblPassword.Visible = true;
            lblPort.Visible = true;

            // Заполняем значениями по умолчанию
            txtServer.Text = "localhost";
            txtDatabase.Text = "infosys";
            txtUser.Text = "postgres";
            txtPassword.Text = "AndiMandi2003";
            txtPort.Text = "5432";

            // Создаем строку соединения
            string connString = $"Host={txtServer.Text};Port={txtPort.Text};Database={txtDatabase.Text};Username={txtUser.Text};Password={txtPassword.Text}";
            connection = new NpgsqlConnection(connString);

            lblStatus.Text = "Соединение инициализировано";

            btnOpen.Enabled = true;
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                lblStatus.Text = "Соединение открыто";
                btnExecute.Enabled = true;
                btnClose.Enabled = true;
                btnOpen.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения: " + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (connection != null && connection.State == ConnectionState.Open)
            {
                connection.Close();
                lblStatus.Text = "Соединение закрыто";
                btnExecute.Enabled = false;
                btnOpen.Enabled = true;
                btnClose.Enabled = false;
            }
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT COUNT(*) FROM users"; // Пример SQL-запроса
                using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                {
                    int count = Convert.ToInt32(command.ExecuteScalar());
                    MessageBox.Show($"Число пользователей в базе: {count}");
                }

                lblStatus.Text = $"Выполнена команда:\n {query}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка выполнения команды: " + ex.Message);
            }
        }
    }
}